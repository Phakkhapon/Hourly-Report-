﻿namespace HourlyReport
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnResetTime = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboProduct = new System.Windows.Forms.ComboBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbtotal = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Selectiontester = new System.Windows.Forms.Label();
            this.lbSelectTst = new System.Windows.Forms.Label();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.lstTester = new System.Windows.Forms.ListBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ByHourly = new System.Windows.Forms.TabPage();
            this.dgvByHourly = new System.Windows.Forms.DataGridView();
            this.Summary = new System.Windows.Forms.TabPage();
            this.dgvSummary = new System.Windows.Forms.DataGridView();
            this.btnExport = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tslStatus = new System.Windows.Forms.ToolStripLabel();
            this.tslProduct = new System.Windows.Forms.ToolStripLabel();
            this.tslbSaveFile = new System.Windows.Forms.ToolStripLabel();
            this.bckWrk = new System.ComponentModel.BackgroundWorker();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.rdAll = new System.Windows.Forms.RadioButton();
            this.rdByPro = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.ByHourly.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvByHourly)).BeginInit();
            this.Summary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummary)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.btnResetTime);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(189, 124);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "TimeSetting";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "dd-MMMM-yyyy HH:mm:ss";
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(13, 71);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(167, 18);
            this.dateTimePicker2.TabIndex = 6;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd-MMMM-yyyy HH:mm:ss";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(13, 34);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(167, 18);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // btnResetTime
            // 
            this.btnResetTime.Location = new System.Drawing.Point(40, 95);
            this.btnResetTime.Name = "btnResetTime";
            this.btnResetTime.Size = new System.Drawing.Size(75, 23);
            this.btnResetTime.TabIndex = 4;
            this.btnResetTime.Text = "ResetTime";
            this.btnResetTime.UseVisualStyleBackColor = true;
            this.btnResetTime.Click += new System.EventHandler(this.btnResetTime_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "EndTime";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "StartTime";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboProduct);
            this.groupBox2.Location = new System.Drawing.Point(215, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(387, 79);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ProductSelection";
            // 
            // cboProduct
            // 
            this.cboProduct.DropDownWidth = 350;
            this.cboProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboProduct.FormattingEnabled = true;
            this.cboProduct.IntegralHeight = false;
            this.cboProduct.Location = new System.Drawing.Point(29, 33);
            this.cboProduct.MaxDropDownItems = 20;
            this.cboProduct.Name = "cboProduct";
            this.cboProduct.Size = new System.Drawing.Size(336, 23);
            this.cboProduct.TabIndex = 1;
            this.cboProduct.SelectedIndexChanged += new System.EventHandler(this.cboProduct_SelectedIndexChanged);
            this.cboProduct.KeyDown += new System.Windows.Forms.KeyEventHandler(this.cboProduct_KeyDown);
            this.cboProduct.MouseHover += new System.EventHandler(this.cboProduct_MouseHover);
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(808, 22);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(91, 34);
            this.btnGenerate.TabIndex = 0;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            this.btnGenerate.MouseHover += new System.EventHandler(this.btnGenerate_MouseHover);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbtotal);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.Selectiontester);
            this.groupBox3.Controls.Add(this.lbSelectTst);
            this.groupBox3.Controls.Add(this.btnClearAll);
            this.groupBox3.Controls.Add(this.btnSelectAll);
            this.groupBox3.Controls.Add(this.lstTester);
            this.groupBox3.Location = new System.Drawing.Point(13, 144);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(189, 460);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tester";
            // 
            // lbtotal
            // 
            this.lbtotal.AutoSize = true;
            this.lbtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtotal.Location = new System.Drawing.Point(130, 414);
            this.lbtotal.Name = "lbtotal";
            this.lbtotal.Size = new System.Drawing.Size(8, 12);
            this.lbtotal.TabIndex = 6;
            this.lbtotal.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(101, 414);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "from ";
            // 
            // Selectiontester
            // 
            this.Selectiontester.AutoSize = true;
            this.Selectiontester.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Selectiontester.Location = new System.Drawing.Point(51, 414);
            this.Selectiontester.Name = "Selectiontester";
            this.Selectiontester.Size = new System.Drawing.Size(31, 12);
            this.Selectiontester.TabIndex = 4;
            this.Selectiontester.Text = "Select";
            // 
            // lbSelectTst
            // 
            this.lbSelectTst.AutoSize = true;
            this.lbSelectTst.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSelectTst.Location = new System.Drawing.Point(86, 414);
            this.lbSelectTst.Name = "lbSelectTst";
            this.lbSelectTst.Size = new System.Drawing.Size(8, 12);
            this.lbSelectTst.TabIndex = 3;
            this.lbSelectTst.Text = "-";
            // 
            // btnClearAll
            // 
            this.btnClearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(98, 430);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(52, 22);
            this.btnClearAll.TabIndex = 2;
            this.btnClearAll.Text = "Clear";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectAll.Location = new System.Drawing.Point(40, 429);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(52, 23);
            this.btnSelectAll.TabIndex = 2;
            this.btnSelectAll.Text = "All";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click_1);
            // 
            // lstTester
            // 
            this.lstTester.FormattingEnabled = true;
            this.lstTester.Location = new System.Drawing.Point(23, 29);
            this.lstTester.Name = "lstTester";
            this.lstTester.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.lstTester.Size = new System.Drawing.Size(147, 381);
            this.lstTester.TabIndex = 0;
            this.lstTester.SelectedIndexChanged += new System.EventHandler(this.lstTester_SelectedIndexChanged);
            this.lstTester.SelectedValueChanged += new System.EventHandler(this.lstTester_SelectedValueChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tabControl1);
            this.groupBox4.Location = new System.Drawing.Point(209, 103);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(788, 501);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Data";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.ByHourly);
            this.tabControl1.Controls.Add(this.Summary);
            this.tabControl1.Location = new System.Drawing.Point(6, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 476);
            this.tabControl1.TabIndex = 1;
            // 
            // ByHourly
            // 
            this.ByHourly.Controls.Add(this.dgvByHourly);
            this.ByHourly.Location = new System.Drawing.Point(4, 22);
            this.ByHourly.Name = "ByHourly";
            this.ByHourly.Padding = new System.Windows.Forms.Padding(3);
            this.ByHourly.Size = new System.Drawing.Size(768, 450);
            this.ByHourly.TabIndex = 0;
            this.ByHourly.Text = "ByHourly";
            this.ByHourly.UseVisualStyleBackColor = true;
            // 
            // dgvByHourly
            // 
            this.dgvByHourly.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvByHourly.Location = new System.Drawing.Point(6, 6);
            this.dgvByHourly.Name = "dgvByHourly";
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            this.dgvByHourly.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvByHourly.Size = new System.Drawing.Size(756, 438);
            this.dgvByHourly.TabIndex = 1;
            // 
            // Summary
            // 
            this.Summary.Controls.Add(this.dgvSummary);
            this.Summary.Location = new System.Drawing.Point(4, 22);
            this.Summary.Name = "Summary";
            this.Summary.Padding = new System.Windows.Forms.Padding(3);
            this.Summary.Size = new System.Drawing.Size(768, 450);
            this.Summary.TabIndex = 1;
            this.Summary.Text = "Summary";
            this.Summary.UseVisualStyleBackColor = true;
            // 
            // dgvSummary
            // 
            this.dgvSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSummary.Location = new System.Drawing.Point(6, 6);
            this.dgvSummary.Name = "dgvSummary";
            this.dgvSummary.Size = new System.Drawing.Size(756, 438);
            this.dgvSummary.TabIndex = 0;
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(808, 62);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(91, 34);
            this.btnExport.TabIndex = 2;
            this.btnExport.Text = "Export";
            this.btnExport.UseVisualStyleBackColor = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            this.btnExport.MouseHover += new System.EventHandler(this.btnExport_MouseHover);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HourlyReport.Properties.Resources.identify_sqlitebrowser;
            this.pictureBox1.Location = new System.Drawing.Point(914, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(77, 79);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tslStatus,
            this.tslProduct,
            this.tslbSaveFile});
            this.toolStrip1.Location = new System.Drawing.Point(0, 627);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1009, 25);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tslStatus
            // 
            this.tslStatus.Name = "tslStatus";
            this.tslStatus.Size = new System.Drawing.Size(51, 22);
            this.tslStatus.Text = "tslStatus";
            // 
            // tslProduct
            // 
            this.tslProduct.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tslProduct.Name = "tslProduct";
            this.tslProduct.Size = new System.Drawing.Size(86, 22);
            this.tslProduct.Text = "toolStripLabel1";
            // 
            // tslbSaveFile
            // 
            this.tslbSaveFile.Name = "tslbSaveFile";
            this.tslbSaveFile.Size = new System.Drawing.Size(12, 22);
            this.tslbSaveFile.Text = "-";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(398, 632);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(300, 18);
            this.progressBar1.TabIndex = 6;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkBox1);
            this.groupBox5.Controls.Add(this.rdAll);
            this.groupBox5.Controls.Add(this.rdByPro);
            this.groupBox5.Location = new System.Drawing.Point(609, 18);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(184, 79);
            this.groupBox5.TabIndex = 7;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Data Selection";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(99, 23);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(66, 17);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Prime(R)";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.MouseHover += new System.EventHandler(this.checkBox1_MouseHover);
            // 
            // rdAll
            // 
            this.rdAll.AutoSize = true;
            this.rdAll.Location = new System.Drawing.Point(9, 43);
            this.rdAll.Name = "rdAll";
            this.rdAll.Size = new System.Drawing.Size(81, 17);
            this.rdAll.TabIndex = 1;
            this.rdAll.TabStop = true;
            this.rdAll.Text = "All Products";
            this.rdAll.UseVisualStyleBackColor = true;
            this.rdAll.MouseHover += new System.EventHandler(this.rdAll_MouseHover_1);
            // 
            // rdByPro
            // 
            this.rdByPro.AutoSize = true;
            this.rdByPro.Location = new System.Drawing.Point(8, 22);
            this.rdByPro.Name = "rdByPro";
            this.rdByPro.Size = new System.Drawing.Size(74, 17);
            this.rdByPro.TabIndex = 0;
            this.rdByPro.TabStop = true;
            this.rdByPro.Text = "ByProduct";
            this.rdByPro.UseVisualStyleBackColor = true;
            this.rdByPro.MouseHover += new System.EventHandler(this.rdByPro_MouseHover);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1009, 652);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMain";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ByHourly.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvByHourly)).EndInit();
            this.Summary.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummary)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgvSummary;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button btnResetTime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Button btnSelectAll;
        public System.Windows.Forms.ListBox lstTester;
        public System.Windows.Forms.ComboBox cboProduct;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel tslStatus;
        private System.Windows.Forms.ToolStripLabel tslProduct;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ToolStripLabel tslbSaveFile;
        private System.ComponentModel.BackgroundWorker bckWrk;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lbtotal;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Selectiontester;
        private System.Windows.Forms.Label lbSelectTst;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage ByHourly;
        private System.Windows.Forms.DataGridView dgvByHourly;
        private System.Windows.Forms.TabPage Summary;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdAll;
        private System.Windows.Forms.RadioButton rdByPro;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

