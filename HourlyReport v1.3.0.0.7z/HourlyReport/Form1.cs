﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using RTTCLib;
using System.Threading;

namespace HourlyReport
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
            //dtpStart = new DateTimePicker();
            //dtpEnd = new DateTimePicker();
        }

        string _exeName;
        string _retErr = null;

        DataTable _AllProduct;
        //int _maxTst;
        //int _maxSld;
        
        private void frmMain_Load(object sender, EventArgs e)
        {
            _exeName = Application.ExecutablePath.Replace(Application.StartupPath, "").Replace("\\", "").Replace(".exe", "").Replace(".EXE", "");
            this.Text = _exeName + "v." + ProductVersion;
            Configure.SetIniPath = Application.StartupPath + @"\" + _exeName + ".ini";
            int ret = Configure.LoadINI;
            if (ret < 0)
            {
                Configure.Server = "172.16.83.5";
                Configure.User = "rttc_net";
                Configure.Password = "rttc_net";
                Configure.Port = "3306";
                //Re Loading
                ret = Configure.LoadINI;
            }

            ResetDate();
            //load product list from database 
            ret = LoadPorduct();
            if (ret < 0)
            {
                MessageBox.Show(_retErr + "please contact Developer Eng.Phakkhapon.W");
            }
            else
            {
                LoadSearchList();
            }
            rdByPro.Checked = true;
            progressBar1.Visible = false;
            tslbSaveFile.Visible = false;
            tslStatus.Text = "Welcome back..." + Environment.MachineName.ToString(); //.Name; 
            tslProduct.Text = cboProduct.Text;           
        }


        #region GUIControl
        private void lstTester_SelectedValueChanged(object sender, EventArgs e)
        {
            UpdateTester();
        }
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstTester.Items.Count; i++)
            {
                lstTester.SelectedIndex = i;
                if (lstTester.GetSelected(i))
                {
                    lstTester.SetSelected(i, false);
                }
                lstTester.TopIndex = 0;
            }
        }
        private void btnSelectAll_Click_1(object sender, EventArgs e)
        {
            try
            {
                lstTester.SelectedItems.Clear();
                for (int i = 0; i < lstTester.Items.Count; i++)
                {
                    lstTester.SetSelected(i, true);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void btnResetTime_Click(object sender, EventArgs e)
        {
            ResetDate();
            dgvSummary.Columns.Clear();          
            lstTester.Text = "";
        }

        private void cboProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            reloadproduct();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            tslbSaveFile.Text = "";
            tslStatus.Text = "Query data from database, please wait...";
            long starttime = DateTime.Now.Ticks;
            int getmode=0;
            if (rdByPro.Checked)
            {
                getmode = 0;
            
            }
            if (rdAll.Checked)
            {
                getmode = 1;
            }

            dgvByHourly.Columns.Clear();
            dgvSummary.Columns.Clear();

            int flagemode;  //0 =  prime   , 1 = all production 
            if (checkBox1.Checked) { flagemode = 0; } else { flagemode = 1; } 
   
            GenerateData(getmode, flagemode);

            long endtime = DateTime.Now.Ticks;
            DateTime Intervaltime = DateTime.FromFileTime(endtime - starttime);
            Single singleInterval = (Intervaltime.Minute * 60) + (Intervaltime.Second) + (Intervaltime.Millisecond / 1000);
            tslStatus.Text = "Query Time = " + string.Format(singleInterval.ToString(), "0.00") + " Sec ";
            Thread.Sleep(10);
            progressBar1.Visible = false;
        }

        private void dtpStart_ValueChanged(object sender, EventArgs e)
        {
            LoadSearchList();
        }
        private void dtpEnd_ValueChanged(object sender, EventArgs e)
        {
            LoadSearchList();
        }
        private void cboProduct_KeyDown(object sender, KeyEventArgs e)
        {
            reloadproduct();
        }

        private void frmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
            this.Close();
        }
        private void btnExport_Click(object sender, EventArgs e)
        {
            int ret = 0;
            string msgContact = "Cannot Export to excel file.Please contact Eng.Phakkhapon.W";
            try
            {
                string tabName = tabControl1.SelectedTab.Name ;     
                tslbSaveFile.Visible = true;
                tslbSaveFile.ForeColor = Color.Black;
          
                if (dgvSummary.RowCount > 0)
                {
                   // CExcelManagment Excel = new CExcelManagment();               
                   Excel excel = new Excel();
                    SaveFileDialog sfd = new SaveFileDialog();
                    sfd.Filter = "Excel Documents (*.xls)|*.xls";
                    sfd.FileName = tabName + "_" + dateTimePicker2.Value.ToString("yyyyMMddHHmmss") + ".xls";
                    if (sfd.ShowDialog() == DialogResult.OK)
                    {                 
                        DataTable dt;
                        if (string.Compare(tabName, "ByHourly") == 0)
                        {
                            dt = (DataTable)(dgvByHourly.DataSource);  //By Hourly Page   
                            ret = excel.ToCsV(dgvByHourly, sfd.FileName);
                        }
                        else if (string.Compare(tabName, "AllProduct") == 0)
                        {
                            dt = (DataTable)(dgvSummary.DataSource);  //All Product Page        
                            ret = excel.ToCsV(dgvSummary, sfd.FileName);
                        }
                        else if (string.Compare(tabName, "Summary") == 0)
                        {
                            dt = (DataTable)(dgvSummary.DataSource);  //Summary Page        
                            ret = excel.ToCsV(dgvSummary, sfd.FileName);
                        }
                        //Excel.ExportDatatableToExcel(dt, sfd.FileName,false);
                        //CDataExport cexport = new CDataExport();
                        //cexport.ExportDatatableToCSV(sfd.FileName, dt, false);
     
                    }

                    if (ret < 0)  // Occurred any error during save file.
                    {
                        MessageBox.Show(excel.RetErr + msgContact);
                    }
                    else
                    {
                        tslbSaveFile.Text = "Export File Complete";
                        tslbSaveFile.ForeColor = Color.Blue;                
                    }
                }
                else
                {
                    tslbSaveFile.Text = "No data.. Please generate the data before export";
                    MessageBox.Show("No data.. Please generate the data before export.");
                }
               
            }
            catch (Exception ex)
            {
                tslbSaveFile.Text = "ex.message" + msgContact;
                MessageBox.Show(ex.Message + msgContact);
            }
        }
        #endregion

        #region HelperMethode
        

        private void ResetDate()
        {
            try
            {
                DateTime startTime = DateTime.Now;
                string start = startTime.Month + @"/" + startTime.Day + @"/" + startTime.Year + " 00:00:00";
                string end = DateTime.Now.Month + @"/" + DateTime.Now.Day + @"/" + DateTime.Now.Year + " 23:59:59";
                dateTimePicker1.Value = Convert.ToDateTime(start);
                dateTimePicker2.Value = Convert.ToDateTime(end);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Function ResetDate Error:" + ex.Message);
            }
        }
        private int LoadPorduct()
        {
            int ret = 0;
            try
            {
                bool chkConnectDB = Configure.OpenDatabase;
                if (chkConnectDB.Equals(false)) { chkConnectDB = Configure.ReOpenDatabase; }
                MySqlConnection myConn = Configure.GetRTTCStringConnection;
                //Load Product
                if (myConn.State == ConnectionState.Closed) { myConn.Open(); } //if connection is closed then reOpen connection 
                CParameterRTTCMapping prodlist = new CParameterRTTCMapping(myConn);
                DataTable dtprod = prodlist.GetProductList(0);
                cboProduct.DisplayMember = "Product";
                cboProduct.DataSource = dtprod;
                _AllProduct = dtprod.Copy();
            }
            catch (Exception ex)
            {
                ret = -1;
                _retErr = ex.Message;
            }
            return ret;

        }
        private void LoadSearchList()
        {
            string prod = cboProduct.Text;
            if (string.IsNullOrEmpty(prod))
            {
                lstTester.Items.Clear();
                lstTester.DataSource = null;
            }
            DateTime dtstart = dateTimePicker1.Value;
            DateTime dtend = dateTimePicker2.Value;
            ListBox.SelectedObjectCollection lstItemSelect = lstTester.SelectedItems;
            int n = lstItemSelect.Count - 1;

            MySqlConnection myConn = Configure.GetRTTCStringConnection;
            if (myConn.State == ConnectionState.Closed) { myConn.Open(); }
            CParameterRTTCMapping paraRTTC = new CParameterRTTCMapping(myConn);

            DataTable dtsearch = paraRTTC.GetSearchListByDate(prod, dtstart, dtend, 0, "", "");
            BindingSource bsSearch = new BindingSource(dtsearch, null);
            lstTester.DataSource = bsSearch;
            lstTester.DisplayMember = "Tester";
            lstTester.ValueMember = "Tester";
            lbtotal.Text = dtsearch.Rows.Count.ToString();
            lbtotal.ForeColor = Color.Blue;
        }
        private void reloadproduct()
        {
            dgvSummary.Columns.Clear();
            string prodname = cboProduct.SelectedText.ToString();
            tslProduct.Text = cboProduct.Text;
            LoadSearchList();
        }
        private void UpdateTester()
        {
            int nItem = lstTester.SelectedItems.Count;
            string strSelect = "Select " + nItem + " From " + lstTester.Items.Count;
        }
        private void GenerateData(int getOption , int flagemode)
        {
            progressBar1.Visible = true;
            progressBar1.Value = 0;
            progressBar1.Minimum = 0;

            MySqlConnection myConn = Configure.GetRTTCStringConnection;
            DataManage dtmanage = new DataManage();
            dtmanage.SetSQLConn = myConn;
            dtmanage.GetFlage = flagemode; // set flage for query data type 

            if (checkBox1.Checked)
            {
                dtmanage.SetDataType = 1;
            }
            else { dtmanage.SetDataType = 0; }

      
            string txtSearch = lstTester.ValueMember.ToString();
            DataTable dtSearch = new DataTable(txtSearch);
            dtSearch.Columns.Add(txtSearch);
           
            if (getOption == 0)
            {
                if (lstTester.SelectedItems.Count > 0) { progressBar1.Maximum = lstTester.SelectedItems.Count - 1; }
                // Add Tester Number from listBox
                if (lstTester.SelectedItems.Count > 0)
                {
                    for (int i = 0; i < lstTester.SelectedItems.Count; i++)
                    {
                        DataRow dr = dtSearch.NewRow();
                        dr[txtSearch] = lstTester.GetItemText(lstTester.SelectedItems[i]);
                        dtSearch.Rows.InsertAt(dr, i);
                        updateprogressbar(i);
                    }
                }
            }
            else
            {
                dtSearch = _AllProduct.Copy();
                if (dtSearch.Rows.Count > 0) { progressBar1.Maximum = dtSearch.Rows.Count - 1; }
            }

            if (dtSearch.Rows.Count > 0)  //Start get data
            {
                DataTable retData;
                DataTable HourlyTable = new DataTable();
                DataTable SumTable = new DataTable();
                DataSet ds = new DataSet();
                dtmanage.BeginTime = dateTimePicker1.Value.ToString("yyyyMMddHHmmss");
                dtmanage.EndTime = dateTimePicker2.Value.ToString("yyyyMMddHHmmss");
                dtmanage.SetOption = getOption;
                if (getOption == 0)
                {
                    dtmanage.SeachBy = dtSearch;
                    dtmanage.Product = cboProduct.Text;
                    retData = dtmanage.RetData;  // Get Data from RTTC Database            
                    if (retData != null) { HourlyTable = retData.Copy(); }    
                    retData = dtmanage.RetDataSumBytester;
                    if (retData != null) { SumTable = retData.Copy(); }                   
                }
                else
                {
                    for (int i = 0; i < dtSearch.Rows.Count; i++)
                    {
                        string prod = dtSearch.Rows[i]["Product"].ToString();
                        dtmanage.Product = prod;

                        retData = dtmanage.RetData;  // Get Data by product by hourly 
                        if (retData != null)
                        {
                            HourlyTable.Merge(retData);
                            retData.TableName = prod;                         
                            if (!ds.Tables.Contains(retData.TableName)) { ds.Tables.Add(retData); }   // Datatable to dataset
                        } // add product by product
                        retData = null;
                        retData = dtmanage.RetDataAllProd;  // get data by product 
                        if (retData != null) { SumTable.Merge(retData); }
                        retData = null;
                        updateprogressbar(i);
                    }
                }
           
                    DataTable hrTabledgv = HourlyTable.Copy();
                    DataTable sumTabledgv = SumTable.Copy();

                    if (getOption == 0)   //by product
                    {
                        sumTabledgv.Columns["Slider_Type"].ColumnName = "Type";    
                        if (sumTabledgv.Columns.Contains("Type")) { sumTabledgv.Columns["Type"].SetOrdinal(1); }
                        if (sumTabledgv.Columns.Contains("Tester")) { sumTabledgv.Columns["Tester"].SetOrdinal(2); }
                        BindingSource bd = new BindingSource();
                        bd.DataSource = sumTabledgv;
                        dgvSummary.DataSource = bd.DataSource;
                        dgvSummary.Columns[1].DisplayIndex = 1;
                        dgvSummary.Columns[2].DisplayIndex = 2;
                       // dgvSummary.DataSource = sumTabledgv;
                        dgvSummary.ReadOnly = true;                     
                        dgvSummary.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
      
                    }
                     else //AllPorduct
                    {
                        sumTabledgv.Columns["Slider_Type"].ColumnName = "Type";
                        if (sumTabledgv.Columns.Contains("Type")) { sumTabledgv.Columns["Type"].SetOrdinal(1); }
                        if (sumTabledgv.Columns.Contains("Tester")) { sumTabledgv.Columns["Tester"].SetOrdinal(2); }
                        BindingSource bd = new BindingSource();
                        bd.DataSource = sumTabledgv;
                        dgvSummary.DataSource = bd.DataSource;
                        dgvSummary.Columns[1].DisplayIndex = 1;
                        dgvSummary.Columns[2].DisplayIndex = 2;
                    //  dgvSummary.DataSource = sumTabledgv;
                        dgvSummary.ReadOnly = true;
                        dgvSummary.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                    }
                    //Convert data for By Hourly report 
                    DataByHr byhr = new DataByHr();
                    byhr.SetTst = dtSearch;
                    DataTable dtConverted = new DataTable();
                    if (getOption == 0)
                    {
                        dtConverted = byhr.ConvertData(hrTabledgv, getOption);
                    }
                    else
                    {
                        for (int i = 0; i < ds.Tables.Count; i++)
                        {
                            string tablename = ds.Tables[i].TableName;
                            DataTable dt = null;
                            dt = byhr.ConvertData(ds.Tables[i], getOption);
                            if (dt != null) { dtConverted.Merge(dt); }
                        }
                    }

                    if (byhr.Ret == 0)
                    {
                        if (dtConverted.Rows.Count > 0)
                        {
                              //  dtConverted.Columns["Slider_Type"].ColumnName = "Type";
                            if (dtConverted.Columns.Contains("Type")) { sumTabledgv.Columns["Type"].SetOrdinal(1); }
                            if (dtConverted.Columns.Contains("Tester")) { sumTabledgv.Columns["Tester"].SetOrdinal(2); }

                            BindingSource bd = new BindingSource();
                            bd.DataSource = dtConverted;
                            dgvByHourly.DataSource = bd.DataSource;
                            dgvByHourly.Columns[1].DisplayIndex = 1;
                            dgvByHourly.Columns[2].DisplayIndex = 2;
                        // dgvByHourly.DataSource = dtConverted;
                        if (getOption == 0) { dgvByHourly.Sort(dgvByHourly.Columns["ProductName"], ListSortDirection.Descending); }  // sort only by product mode
                            dgvByHourly.ReadOnly = true;
                            dgvByHourly.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                            dgvByHourly.BackgroundColor = Color.AliceBlue;
                        }
                    }
                    else { MessageBox.Show("Table ByHourly Report alert information : ." + byhr.RetErr + "\n Please contact Eng.Phakkhapon.W"); }
                    Application.DoEvents();
                    HourlyTable = null;
                    SumTable = null;
                    ds = null;
                    retData = null;     
            }
            else { MessageBox.Show("No Tester Selection"); }
        }

        private void lstTester_SelectedIndexChanged(object sender, EventArgs e)
        {
           lbSelectTst.Text = lstTester.SelectedItems.Count.ToString();
           lbSelectTst.ForeColor = Color.Blue;
        }

        private void updateprogressbar(int i)
        {
            MethodInvoker inv = delegate //update progress bar
            {
                progressBar1.Value = i;
            };
            this.Invoke(inv);

        }

        #endregion


        private void checkBox1_MouseHover(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.Show("Tick เพื่อ Get Data Prime Spec R",checkBox1,0,20,1200);
            //Checked to be generated only Prime Spec R
        }

        private void cboProduct_MouseHover(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.Show("เลือก product ทีต้องการ Get Data", cboProduct, 0, 20, 1200);
        }

        private void rdByPro_MouseHover(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.Show("Tick Get Data by Product", rdByPro, 0, 20, 1200);
        }
        private void rdAll_MouseHover_1(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.Show("Tick Get Data all Products", rdAll, 0, 20, 1200);
        }

        private void btnGenerate_MouseHover(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.Show("Click Generate Data", btnGenerate, 0, 20, 1200);
        }

        private void btnExport_MouseHover(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.Show("Click Export Data to csv format", btnExport, 0, 20, 1200);
        }

    
    }
}
