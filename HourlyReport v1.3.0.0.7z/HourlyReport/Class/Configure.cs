﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Data;
using MyLibByCCharp;

namespace HourlyReport
{
    static class Configure
    {
        static string _iniPath, _server, _user, _pw, _port;
        static string _database;
        static string _retErr;
      //  static LoadConfigIni _loadini = new LoadConfigIni();
        static MySqlConnection _MySqlRTTCDataConn = new MySqlConnection();
        #region Properties
        public static int LoadINI
        {
            get {
                 int ret = 0;
                ret = Readini();
                return ret;
                }
        }
        public static string GetERR { get { return _retErr; } }
        public static string SetIniPath { set { _iniPath = value; } }
        public static string Server { get { return _server; } set { _server = value; } }
        public static string User { get { return _user; } set { _user = value; } }
        public static string Password { get { return _pw; } set { _pw = value;  } }
        public static string Port { get { return _port; } set { _port = value; } }
        #endregion

        private static int Readini()
        {
            int ret=0;
            try
            {
              //  LoadConfigIni loadini = new LoadConfigIni();
                if (File.Exists(_iniPath))
                {
                    IniFile ini = new IniFile(_iniPath);
                    _server = ini.Read("server", "serverConfig");
                    _user = ini.Read("user", "serverConfig");
                    _pw = ini.Read("pw", "serverConfig");
                    _port = ini.Read("port", "serverConfig");
                    _database = ini.Read("database", "serverConfig");
                }
                else { ReInitialConfigure(); }
            }
            catch (Exception ex)
            {
                ret = -1;
                _retErr = ex.Message;
            }   
          return ret;
        }

        private static void ReInitialConfigure()
        {
            SetDBConfig();
            IniFile ini = new IniFile(_iniPath);
            ini.Write("server", _server, "ServerConfig");
            ini.Write("user", _user, "ServerConfig");
            ini.Write("pw", _pw, "ServerConfig");
            ini.Write("port", _port, "ServerConfig");
            ini.Write("database", _database, "ServerConfig");
        }

        private static void SetDBConfig()
        {
            _server = "172.16.83.5";
            _user = "rttc_net";
            _pw = "rttc_net";
            _port = "3306";
            _database = "";
        }

        #region SQL
        public static MySqlConnection GetRTTCStringConnection
        {
            get
            {
                if (string.IsNullOrEmpty(_MySqlRTTCDataConn.ConnectionString))
                {
                    SetRTTCStringConnecttion();
                    return _MySqlRTTCDataConn;
                }
                else
                {              
                    return _MySqlRTTCDataConn;
                }
            }
        }
        public static bool OpenDatabase
        {
            get
            {
                bool ChkConnection = false;
                ChkConnection = OpendDatabaseConnection();
                return ChkConnection;
            }
        }
        public static bool CloseDatabase
        {
            get
            {
                bool ChkConnection = false;
                ChkConnection = CloseDatabaseConnection();
                return ChkConnection;
            }
        }
        public static bool ReOpenDatabase
        {
            get
            {
                bool ChkConnection = false;
                ChkConnection = ReOpenDatabaseConnection();
                return ChkConnection;
            }
        }
        //----------end SQL Management------------
        public static string SetDatabase
        {
            set { _database = value; }
        }
        public static string GetConnString
        {
            get
            {
                string connstring = null;
                if (string.IsNullOrEmpty(_server))
                {
                    return "Server is not correct";
                }
                else
                {
                    connstring = SetConnString();
                    return connstring;
                }
            }
        }
 
        private static string SetConnString()
        {
            string sqlconn = "server=" + _server + ";";
            sqlconn = sqlconn + "uid=" + _user + ";";
            sqlconn = sqlconn + "pwd=" + _pw + ";";
            if (string.IsNullOrEmpty(_database))
            {
                sqlconn = sqlconn + "port=" + _port + ";";
                sqlconn = sqlconn + "Connection Lifetime=15" + ";";
            }
            else
            {
                sqlconn = sqlconn + "database=" + _database + ";";
                sqlconn = sqlconn + "port=" + _port + ";";
                sqlconn = sqlconn + "Connection Lifetime=15" + ";";
            }
            return sqlconn;
        }
        private static bool SetRTTCStringConnecttion()
        {
            bool ret = true ;
            try
            {
                if (_MySqlRTTCDataConn == null)
                {
                    _MySqlRTTCDataConn = new MySqlConnection();
                }
                if (_MySqlRTTCDataConn.State == ConnectionState.Open) { _MySqlRTTCDataConn.Close(); }
                _MySqlRTTCDataConn.ConnectionString = SetConnString();
                ret = true;
            }
            catch (Exception ex)
            {
                ret = false;
                _retErr= ex.Message;
            }
            return ret;
        }
        private static bool OpendDatabaseConnection()
        {
            bool chkState = true;
            try
            {
                if (_MySqlRTTCDataConn.ConnectionString == null)
                {
                   // _MySqlRTTCDataConn = new MySqlConnection();
                    SetRTTCStringConnecttion();
                    if (_MySqlRTTCDataConn.State == ConnectionState.Closed) { _MySqlRTTCDataConn.Open(); }
                }
                if (_MySqlRTTCDataConn.State == ConnectionState.Open)
                {
                    chkState = true;
                }
                else { chkState = false; }
            }
            catch (Exception ex)
            {
                chkState = false;
                _retErr = ex.Message;
            }
            return chkState;
        }
        private static bool CloseDatabaseConnection()
        {
            bool chkState = true;
            try
            {
                if (_MySqlRTTCDataConn.ConnectionString == null)
                {
                  //  _MySqlRTTCDataConn = new MySqlConnection();
                    SetRTTCStringConnecttion();
                    if (_MySqlRTTCDataConn.State == ConnectionState.Open) { _MySqlRTTCDataConn.Close(); }
                }
                if (_MySqlRTTCDataConn.State == ConnectionState.Closed)
                {
                    chkState = true;
                }
                else { chkState = false;}
            }
            catch (Exception ex)
            {
                chkState = false;
                _retErr = ex.Message;
            }

            return chkState;
        }
        private static bool ReOpenDatabaseConnection()
        {
            bool chkState = true;
            chkState = CloseDatabaseConnection();
            chkState = OpendDatabaseConnection();
            return chkState;
        }
        #endregion
    

    }

}
