﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyLibByCCharp;
using RTTCLib;
using System.Data;
using MySql.Data.MySqlClient;

namespace HourlyReport
{
    class DataManage
    {
        private string _productName;
        private string _retErr;
        private string _startTime;
        private string _endTime;
        private DataTable _dtRet = new DataTable();//= new DataTable();
        private DataTable _dtSearch;
        private MySqlConnection _conn;
        private int _getOption;
        private int _flagemode;
     
        #region properties 
        public string Product { set { _productName = value; } }
        public string BeginTime { set { _startTime = value; } }
        public string EndTime { set { _endTime = value; } }
        public int GetFlage { set { _flagemode = value; } }

        public DataTable RetData
        { get
            {
                int ret=0; 
                if (!string.IsNullOrEmpty(_productName))
                {
                    ret = GetData();
                }
                if (ret < 0)
                {
                    if (string.IsNullOrEmpty(_retErr)) { _retErr = "Not found data"; }               
                    _dtRet = null;
                }
                return _dtRet;
            }
        }

        public DataTable RetDataAllProd
        {
            get
            {
                int ret = 0;
                if (!string.IsNullOrEmpty(_productName))
                {
                    ret = GetDataAllProduct();
                }
                if (ret < 0)
                {
                    _retErr = "Not found data";
                    _dtRet = null;
                }
                return _dtRet;
            }
        }


        public DataTable RetDataSumBytester
        {
            get
            {
                int ret = 0;
                if (!string.IsNullOrEmpty(_productName))
                {
                    ret = GetDataSumByTester();
                }
                if (ret < 0)
                {
                    _retErr = "Not found data";
                    _dtRet = null;
                }
                return _dtRet;
            }
        }

        private int _prime;  // 0 = All , 1 = Prime only Spec "R" 
        public int SetDataType
        {
            get { return _prime; }
            set { _prime = value; }
        }

        public DataTable SeachBy { set { _dtSearch = value; } }
        public MySqlConnection SetSQLConn { set { _conn = value; } } //set sql connectoin 
        public string RetErr { get{ return _retErr; } }
        public int SetOption { set { _getOption = value; } }

        #endregion
        #region methode
        private int GetData()
        {
            int ret=0;
            DataTable dt = new DataTable();
            try
            {
                    string sqlCmd = null;
                if (_getOption == 0) { sqlCmd = SetSqlQueryByTester(_dtSearch,_flagemode); }  //by tester
                else { sqlCmd = SetSqlQueryByProduct(_productName); }  // by product
                ret = ExcuteQuery(sqlCmd,ref dt);  //reference datable
                if (dt.Rows.Count > 0)
                {
                    ret = 0;
                    _dtRet = dt.Copy();  //Return datable 
                }
                else
                {
                    ret = -1;
                    _retErr = "Database was no data";
                }
        
            }
            catch (Exception ex)
            {
                ret=-1;
                _retErr = ex.Message;
            }     
            return ret;

        }


        private int GetDataAllProduct()
        {
            int ret = 0;
            DataTable dt = new DataTable();
            try
            {
                string sqlCmd = SetSqlQueryAllProduct(_productName,_flagemode);
                ret = ExcuteQuery(sqlCmd, ref dt);  //reference datable
                if (dt.Rows.Count > 0)
                {
                    ret = 0;
                    _dtRet = dt.Copy();  //Return datable 
                }
                else
                {
                    ret = -1;
                    _retErr = "Database was no data";
                }

            }
            catch (Exception ex)
            {
                ret = -1;
                _retErr = ex.Message;
            }
            return ret;

        }

        private int GetDataSumByTester()
        {
            int ret = 0;
            DataTable dt = new DataTable();
            try
            {
                string sqlCmd = SetSqlQuerySumbyTester(_dtSearch,_flagemode);
                ret = ExcuteQuery(sqlCmd, ref dt);  //reference datable
                if (dt.Rows.Count > 0)
                {
                    ret = 0;
                    _dtRet = dt.Copy();  //Return datable 
                }
                else
                {
                    ret = -1;
                    _retErr = "Database was no data";
                }

            }
            catch (Exception ex)
            {
                ret = -1;
                _retErr = ex.Message;
            }
            return ret;

        }


        #endregion

        #region Database

        private string SetSqlQueryByTester(DataTable dtsearch)
        {
            string sql = null ;
            sql = "SELECT '" + _productName + "' ProductName,";
            sql = sql + " CAST(DATE_FORMAT(DATE_ADD(Test_time,INTERVAL 1 HOUR),'%Y-%m-%d %H:00:00') AS DATETIME) Date_Time,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,Tester,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";

            sql = sql + " FROM db_" + _productName + ".tabdetail_header";
            sql = sql + " WHERE (";
           string getTst = "";
            string tstName = "";
            if (dtsearch.Rows.Count > 1)
            {
                for (int i = 0; i < dtsearch.Rows.Count; i++)
                {
                    tstName = dtsearch.Rows[i]["Tester"].ToString();
                    getTst = getTst + "Tester= '" + tstName  + "'";
                    if (!string.IsNullOrEmpty(tstName) && i < dtsearch.Rows.Count) { getTst = getTst + " OR "; }                                       
                }
                string txt = ManageString.Right(getTst, 3);
                string rettxt = null;
             if (string.Compare(txt, "OR ") == 0) { rettxt = getTst.Remove(getTst.Length - 3, 3); }  // compare string 
                sql = sql + rettxt;
            }
            else  // select one tester
            {
                tstName = dtsearch.Rows[0]["Tester"].ToString();
                sql = sql + "Tester= '" + tstName + "'";
            }        
            sql = sql + ")";
            sql = sql + " AND GradeName IS NOT NULL AND Spec LIKE 'R%'";
            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY DATE_FORMAT(Test_time,'%Y%m%d%k'),Tester";           
            sql = sql + " ORDER BY Date_Time,Tester,Test_time_bigint; ";
            return sql;
        }
        
        private string SetSqlQueryByTester(DataTable dtsearch,int flagmode = 1)  // 1 = all include retest
        {
            string sql = null;
            sql = "SELECT '" + _productName + "' ProductName,";
            sql = sql + " CAST(DATE_FORMAT(DATE_ADD(Test_time,INTERVAL 1 HOUR),'%Y-%m-%d %H:00:00') AS DATETIME) Date_Time,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,Tester,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";

            sql = sql + " FROM db_" + _productName + ".tabdetail_header";
            sql = sql + " WHERE (";
            string getTst = "";
            string tstName = "";
            if (dtsearch.Rows.Count > 1)
            {
                for (int i = 0; i < dtsearch.Rows.Count; i++)
                {
                    tstName = dtsearch.Rows[i]["Tester"].ToString();
                    getTst = getTst + "Tester= '" + tstName + "'";
                    if (!string.IsNullOrEmpty(tstName) && i < dtsearch.Rows.Count) { getTst = getTst + " OR "; }
                }
                string txt = ManageString.Right(getTst, 3);
                string rettxt = null;
                if (string.Compare(txt, "OR ") == 0) { rettxt = getTst.Remove(getTst.Length - 3, 3); }  // compare string 
                sql = sql + rettxt;
            }
            else  // select one tester
            {
                tstName = dtsearch.Rows[0]["Tester"].ToString();
                sql = sql + "Tester= '" + tstName + "'";
            }
            sql = sql + ")";
            sql = sql + " AND GradeName IS NOT NULL";

            querymode(ref sql, flagmode);

            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY DATE_FORMAT(Test_time,'%Y%m%d%k'),Tester";
            sql = sql + " ORDER BY Date_Time,Tester,Test_time_bigint; ";
            return sql;
        }



        private string SetSqlQueryByProduct(string productseach)
        {
            string sql = null;
            sql = "SELECT '" + productseach + "' ProductName,";
            sql = sql + " CAST(DATE_FORMAT(DATE_ADD(Test_time,INTERVAL 1 HOUR),'%Y-%m-%d %H:00:00') AS DATETIME) Date_Time,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";
            sql = sql + " FROM db_" + productseach + ".tabdetail_header";
            sql = sql + " WHERE GradeName IS NOT NULL AND Spec LIKE 'R%'";
            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY Date_Time,Slider_Type ";
            sql = sql + " ORDER BY Date_Time,Slider_Type; ";
            return sql;
        }



        private string SetSqlQueryByProduct(string productseach,int flagemode)
        {
            string sql = null;
            sql = "SELECT '" + productseach + "' ProductName,";
            sql = sql + " CAST(DATE_FORMAT(DATE_ADD(Test_time,INTERVAL 1 HOUR),'%Y-%m-%d %H:00:00') AS DATETIME) Date_Time,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";
            sql = sql + " FROM db_" + productseach + ".tabdetail_header";
            sql = sql + " WHERE GradeName IS NOT NULL";

            querymode(ref sql, flagemode);
            
            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY Date_Time,Slider_Type ";
            sql = sql + " ORDER BY Date_Time,Slider_Type; ";
            return sql;
        }



        private string SetSqlQueryAllProduct(string productseach)
        {
            string sql = null;
            sql = "SELECT '" + productseach + "' ProductName,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";
            sql = sql + " FROM db_" + productseach + ".tabdetail_header";
            sql = sql + " WHERE GradeName IS NOT NULL AND Spec LIKE 'R%'";
            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY Slider_Type ";
            sql = sql + " ORDER BY ProductName,Slider_Type;";
            return sql;
        }


        private string SetSqlQueryAllProduct(string productseach,int flagemode)
        {
            string sql = null;
            sql = "SELECT '" + productseach + "' ProductName,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";
            sql = sql + " FROM db_" + productseach + ".tabdetail_header";
            sql = sql + " WHERE GradeName IS NOT NULL";

            querymode(ref sql, flagemode);

            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY Slider_Type ";
            sql = sql + " ORDER BY ProductName,Slider_Type;";
            return sql;
        }


        private string SetSqlQuerySumbyTester(DataTable dtsearch)
        {
            string sql = null;
            sql = "SELECT '" + _productName + "' ProductName,";           
            sql = sql + " RIGHT(Spec,1) Slider_Type,Tester,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";

            sql = sql + " FROM db_" + _productName + ".tabdetail_header";
            sql = sql + " WHERE (";
            string getTst = "";
            string tstName = "";
            if (dtsearch.Rows.Count > 1)
            {
                for (int i = 0; i < dtsearch.Rows.Count; i++)
                {
                    tstName = dtsearch.Rows[i]["Tester"].ToString();
                    getTst = getTst + "Tester= '" + tstName + "'";
                    if (!string.IsNullOrEmpty(tstName) && i < dtsearch.Rows.Count) { getTst = getTst + " OR "; }
                }
                string txt = ManageString.Right(getTst, 3);
                string rettxt = null;
                if (string.Compare(txt, "OR ") == 0) { rettxt = getTst.Remove(getTst.Length - 3, 3); }  // compare string 
                sql = sql + rettxt;
            }
            else  // select one tester
            {
                tstName = dtsearch.Rows[0]["Tester"].ToString();
                sql = sql + "Tester= '" + tstName + "'";
            }
            sql = sql + ")";
            sql = sql + " AND GradeName IS NOT NULL AND Spec LIKE 'R%'";
            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY Tester";
            sql = sql + " ORDER BY Tester,Slider_Type; ";
            return sql;
        }

        private string SetSqlQuerySumbyTester(DataTable dtsearch,int flagemode)
        {
            string sql = null;
            sql = "SELECT '" + _productName + "' ProductName,";
            sql = sql + " RIGHT(Spec,1) Slider_Type,Tester,";
            sql = sql + " COUNT(GradeName)'Total_TestIn',COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END)'Total_PassBin5',";
            sql = sql + " (COUNT(GradeName)-COUNT(CASE WHEN GradeName LIKE 'PASS_BIN5%' THEN 1 END))'Excluded_PassBin5'";

            sql = sql + " FROM db_" + _productName + ".tabdetail_header";
            sql = sql + " WHERE (";
            string getTst = "";
            string tstName = "";
            if (dtsearch.Rows.Count > 1)
            {
                for (int i = 0; i < dtsearch.Rows.Count; i++)
                {
                    tstName = dtsearch.Rows[i]["Tester"].ToString();
                    getTst = getTst + "Tester= '" + tstName + "'";
                    if (!string.IsNullOrEmpty(tstName) && i < dtsearch.Rows.Count) { getTst = getTst + " OR "; }
                }
                string txt = ManageString.Right(getTst, 3);
                string rettxt = null;
                if (string.Compare(txt, "OR ") == 0) { rettxt = getTst.Remove(getTst.Length - 3, 3); }  // compare string 
                sql = sql + rettxt;
            }
            else  // select one tester
            {
                tstName = dtsearch.Rows[0]["Tester"].ToString();
                sql = sql + "Tester= '" + tstName + "'";
            }
            sql = sql + ")";
            sql = sql + " AND GradeName IS NOT NULL";

            querymode(ref sql, flagemode);

            sql = sql + " AND (test_time_bigint BETWEEN '" + _startTime + "' AND '" + _endTime + "')";
            sql = sql + " GROUP BY Tester";
            sql = sql + " ORDER BY Tester,Slider_Type; ";
            return sql;
        }


        private int ExcuteQuery(string sqlCmd ,ref DataTable dt)
        {
            int ret=0;
            try
            {
                if (_conn.State == ConnectionState.Closed) { _conn.Open(); }
                if (!string.IsNullOrEmpty(sqlCmd))
                {
                    DataSet ds = new DataSet();
                    MySqlDataAdapter da = new MySqlDataAdapter(sqlCmd, _conn);
                    da.Fill(ds);
                    if (dt != null)
                    {
                        dt.Reset();
                        dt = ds.Tables[0].Copy();
                    }   
                }
                else
                {
                    MySqlCommand cmd = new MySqlCommand(sqlCmd,_conn);
                    ret = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
               ret = -1;
               _retErr ="ExcuteSqlQuery" + ex.Message ;
            }
            return ret;
        }

        private void querymode(ref string sql, int flagemode)
        {
            if (flagemode == 0)
            {
                sql = sql + " AND Spec LIKE 'R%'";               
            }
            else
            {
                sql = sql + " AND TestMode = '0'"; // all production
            }

        }

        #endregion

    }
}
