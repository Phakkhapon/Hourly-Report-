﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;

namespace HourlyReport
{
    class DataByHr
    {
        string _retErr;
        int _ret;
        DataTable _lstSeach;

        #region Properties
        public string RetErr { get { return _retErr; } }
        public int Ret { get { return _ret; } }
        public DataTable SetTst { set { _lstSeach = value; } }

        public Func<string> stCol { get; private set; }
        #endregion

        #region Methode
        public DataTable ConvertData(DataTable rawdata, int getoption)
        {
            DataTable retTable = new DataTable();      
            if (getoption == 0)
            {
                retTable.Columns.Add("ProductName").SetOrdinal(0);
                retTable.Columns.Add("Type").SetOrdinal(1);
                retTable.Columns.Add("Tester").SetOrdinal(2);              
                _ret = ConvertByTester(rawdata,ref retTable, "Tester");
            }
            else
            {
                retTable.Columns.Add("ProductName").SetOrdinal(0);
                retTable.Columns.Add("Type").SetOrdinal(1);
                _ret = ConvertByProduct(rawdata, ref retTable, "Slider_Type");

            }
            return retTable;            
        }
        private int ConvertByTester(DataTable rawdata , ref DataTable retTable, string convertby)
        {
            int ret=0;
            try
            {
                if (rawdata.Rows.Count > 0)
                {
                    //  DataColumn dc = new DataColumn();
                    foreach (DataColumn dc in rawdata.Columns)
                    {
                        if (string.Compare(dc.ColumnName, "Date_Time") == 0)
                        {
                            for (int i = 0; i < _lstSeach.Rows.Count; i++)
                            {
                                retTable.Rows.Add();
                                string tstName = _lstSeach.Rows[i][convertby].ToString();
                                DataRow dr;
                                for (int j = 0; j < rawdata.Rows.Count; j++)
                                {
                                    //Prepare info
                                    string colname = rawdata.Rows[j]["Date_Time"].ToString();
                                    string prod = rawdata.Rows[j]["ProductName"].ToString();
                                    string Tst = rawdata.Rows[j][convertby].ToString();
                                    string Type = rawdata.Rows[j]["Slider_Type"].ToString();
                                    string Bin5 = rawdata.Rows[j]["Excluded_PassBin5"].ToString();

                                    if (string.Compare(tstName, Tst) == 0)
                                    {
                                        bool chkCol = checkColumnName(retTable, colname);  ///Is column already belong or not ? Return false  
                                        if (chkCol == false) { retTable.Columns.Add(); }
                                        int nCol = retTable.Columns.Count - 1;
                                        if (retTable.Columns[nCol].ColumnName != colname && retTable.Columns[nCol].ColumnName != convertby && chkCol == false)
                                        {
                                            retTable.Columns[nCol].ColumnName = colname;
                                        }
                                        dr = rawdata.Rows[j];
                                        if ((retTable.Rows.Count - 1) == i)
                                        {
                                            retTable.Rows[retTable.Rows.Count - 1]["ProductName"] = dr.ItemArray[0];
                                            retTable.Rows[retTable.Rows.Count - 1]["Type"] = dr.ItemArray[2];
                                            retTable.Rows[retTable.Rows.Count - 1][convertby] = dr.ItemArray[3];                                           
                                            retTable.Rows[retTable.Rows.Count - 1][colname] = dr.ItemArray[6];
                                        }
                                    }
                                }
                            }
                            break;//exit loop due to Col was changed                       
                        }
                    }
                }
                else
                {
                    ret = -1;
                    _retErr = "Raw Data is not valid";
                }
            }
            catch (Exception ex)
            {

                ret = -1;
                _retErr = "Convert Data is not complete : " + ex.Message;
            }
            return ret;
        }

        private int ConvertByProduct(DataTable rawdata, ref DataTable retTable, string convertby)
        {
            int ret = 0;
            try
            {
                DataTable seachTable = rawdata.DefaultView.ToTable(false, "Slider_Type");  // Select product name
                seachTable = RemoveDuplicateRows(seachTable, "Slider_Type");  // remove duplicate item

                DataTable dt = new DataTable();
                dt = rawdata.Copy();
                dt.DefaultView.Sort = "Slider_Type asc";
                dt = dt.DefaultView.ToTable();

                if (dt.Rows.Count > 0)
                {
                    //  DataColumn dc = new DataColumn();
                    foreach (DataColumn dc in dt.Columns)
                    {
                        if (string.Compare(dc.ColumnName, "Date_Time") == 0)
                        {
                            for (int i = 0; i < seachTable.Rows.Count; i++)
                            {
                                retTable.Rows.Add();
                                string refType = seachTable.Rows[i][convertby].ToString();
                                DataRow dr;
                                for (int j = 0; j < dt.Rows.Count; j++)
                                {
                                    //Prepare info
                                    string colname = dt.Rows[j]["Date_Time"].ToString();
                                    string prod = dt.Rows[j]["ProductName"].ToString();                                
                                    string Type = dt.Rows[j]["Slider_Type"].ToString();
                                    string Bin5 = dt.Rows[j]["Excluded_PassBin5"].ToString();

                                    if (string.Compare(refType, Type) == 0)
                                    {
                                        bool chkCol = checkColumnName(retTable, colname);  ///Is column already belong or not ? Return false  
                                        if (chkCol == false) { retTable.Columns.Add(); }
                                        int nCol = retTable.Columns.Count - 1;
                                        if (retTable.Columns[nCol].ColumnName != colname && retTable.Columns[nCol].ColumnName != convertby && chkCol == false)
                                        {
                                            retTable.Columns[nCol].ColumnName = colname;
                                        }
                                        dr = dt.Rows[j];
                                        int x = retTable.Rows.Count - 1;
                                        string prodduct = retTable.Rows[x]["ProductName"].ToString();
                                        if (string.IsNullOrEmpty(prodduct))
                                        {
                                            retTable.Rows[x]["ProductName"] = dr.ItemArray[0];
                                            retTable.Rows[x]["Type"] = dr.ItemArray[2];
                                            retTable.Rows[x][colname] = dr.ItemArray[5];
                                        }
                                        else
                                        {
                                            retTable.Rows[x]["ProductName"] = dr.ItemArray[0];
                                            retTable.Rows[x]["Type"] = dr.ItemArray[2];
                                            retTable.Rows[x][colname] = dr.ItemArray[5];
                                        }
                                    }
                                }
                            }
                            break;//exit loop due to Col was changed                                               
                        }
                    }
                }
                else
                {
                    ret = -1;
                    _retErr = "Raw Data is not valid";
                }
            }
            catch (Exception ex)
            {
                ret = -1;
                _retErr = "Convert Data is not complete : " + ex.Message;
            }
            return ret;
        }

        private bool checkColumnName(DataTable dt , string colname)
        {
            bool ret = false;  // not same 
            foreach (DataColumn dc in dt.Columns)
            {
                if (string.Compare(dc.ColumnName, colname) == 0)
                {
                    ret = true;  // same colname return true
                }
            }

            return ret;
        }
        public DataTable RemoveDuplicateRows(DataTable dTable, string colName)
        {
            Hashtable hTable = new Hashtable();
            ArrayList duplicateList = new ArrayList();

            //Add list of all the unique item value to hashtable, which stores combination of key, value pair.
            //And add duplicate item value in arraylist.
            foreach (DataRow drow in dTable.Rows)
            {
                if (hTable.Contains(drow[colName]))
                    duplicateList.Add(drow);
                else
                    hTable.Add(drow[colName], string.Empty);
            }

            //Removing a list of duplicate items from datatable.
            foreach (DataRow dRow in duplicateList)
                dTable.Rows.Remove(dRow);

            //Datatable which contains unique records will be return as output.
            return dTable;
        }
        #endregion

    }

}
